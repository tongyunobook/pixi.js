
module.exports = {
    webGL: require('./webgl/WebGLExtract'),
    canvas: require('./canvas/CanvasExtract')
};